CHOTU BIRTHDAY WEBSITE — V2

Open index.html.

PHOTO:
Tap each photo frame and select an image. The images remain local in the browser.

MUSIC:
The website is ready for a local audio file. For example, put your own copy of the song in this folder as music.mp3 and change:
<audio id="song" loop></audio>
to:
<audio id="song" loop src="music.mp3"></audio>
The song starts after the envelope is tapped, which works better with browser autoplay rules.

EDITING:
All text is in index.html. CSS is in style.css and interactions are in script.js.

HOSTING:
Upload the folder to any static website host, or open index.html directly on a device.
