const song=document.getElementById("song");
function openGift(){
 document.getElementById("envelopeScreen").style.display="none";
 document.getElementById("journey").classList.remove("hidden");
 if(song.src) song.play().catch(()=>{});
 burst(20);
 document.querySelector(".hero").scrollIntoView();
}
function go(id){document.getElementById(id).scrollIntoView({behavior:"smooth"})}
let found=0;
function reason(btn){
 if(btn.classList.contains("done"))return;
 btn.classList.add("done");found++;
 document.getElementById("reasonHint").textContent=found+" / 4 discovered";
 if(found===4){
   document.getElementById("reasonHint").textContent="4 / 4 discovered · You found them all. ♡";
   document.getElementById("reasonNext").classList.add("ready");
   burst(10);
 }
}
function photo(input,i){
 const f=input.files[0];if(!f)return;
 const r=new FileReader();
 r.onload=e=>document.getElementById("p"+i).src=e.target.result;
 r.readAsDataURL(f);
}
function finale(){
 document.querySelectorAll(".screen").forEach(x=>x.style.display="none");
 document.getElementById("finale").classList.add("show");
 window.scrollTo({top:0,behavior:"smooth"});
 burst(50);
}
function burst(n){
 for(let i=0;i<n;i++){
  const x=document.createElement("i");
  x.textContent=["✦","♡","·","✧"][Math.floor(Math.random()*4)];
  x.style.position="fixed";x.style.zIndex=50;x.style.left="50%";x.style.top="45%";
  x.style.fontSize=(10+Math.random()*22)+"px";x.style.opacity="1";
  x.style.transition="transform 1.5s ease,opacity 1.5s ease";
  document.body.appendChild(x);
  requestAnimationFrame(()=>{x.style.transform=`translate(${(Math.random()-.5)*650}px,${(Math.random()-.5)*600}px) rotate(${Math.random()*360}deg)`;x.style.opacity="0"});
  setTimeout(()=>x.remove(),1600);
 }
}
